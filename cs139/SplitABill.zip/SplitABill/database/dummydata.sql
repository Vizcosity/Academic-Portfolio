INSERT INTO users VALUES(NULL, "blake", NULL, "blake", "something@gmail.com", "test", "235235", NULL);
