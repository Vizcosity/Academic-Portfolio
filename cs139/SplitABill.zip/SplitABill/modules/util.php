<?php
// This file contains a set of useful functions that can be used across the SplitABill backend.


?>
