<?php

// Takes in the userID and clears their notification queue.

session_start();


error_reporting(E_ALL);
ini_set("display_errors", 1);

include("database.php");
$db = new Database();

$statement = $db->prepare("DELETE FROM notifications WHERE uID=:uID OR gID IN (SELECT groupID FROM usersInGroup WHERE userID=:uID) or bID in (SELECT billID FROM usersInBill WHERE userID=:uID)");
$statement->bindValue(":uID", $_POST['userID'], SQLITE3_INTEGER);

$statement->execute();

// User notification queue should now be clear.

?>
