<?php


error_reporting(E_ALL);
ini_set("display_errors", 1);

include("database.php");
$db = new Database();


// Remove user from a specified group.
$statement = $db->prepare("DELETE FROM usersInGroup WHERE userID=:userID AND groupID:groupID");
$statement->bindValue(":userID", $_POST['userID'], SQLITE3_INTEGER);
$statement->bindValue(":groupID", $_POST['groupID'], SQLITE3_INTEGER);

$statement->execute();

// user should now be removed from the group.
?>
