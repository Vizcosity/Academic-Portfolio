$(document).ready(function(){

  var clipboard = new Clipboard('p.joinToken');

  // Copy the token / joinlink on click.
  $('p.joinToken').click(function(){
    // Copy to clipboard and toast to notify of copy.
    Materialize.toast('Copied!', 4000) // 4000 is the duration of the toast
  });

  // Add remove button logic
  $('#leave-button').click(function(){

      var userID = $('#leave-button').data('user-id');
      var groupID = $('#leave-button').data('group-id');

      console.log(userID);
      console.log(groupID);

      // Send a post request to leaveGroup.
      $.post("../modules/leaveGroup.php", {
        userID: userID,
        groupID: groupID
      }, function(response){
        console.log(response);
        window.location = "dashboard.php?message=Group removed.";
      });
  });

});
